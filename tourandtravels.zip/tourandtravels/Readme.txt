Tourism Management System in PHP-----Installation Steps(Configuration)

1.Download and Unzip the file on your local system.
2.Copy tms folder and paste inside the xampp/htdcos 

For Example: C:\xampp\htdocs

3.Database Configuration

Open PHPMyAdmin
Create Database tms
Import database tms.sql (available inside the zip package)
Open Your browser put inside browser http://localhost/tms

Login Details for admin : 
Open Your browser put inside browser “http://localhost/tms/admin”

*****Admin Login Details******
Username: admin
Password: Test@123

*****Login Details for user*****
Username: test@gmail.com
Password: Test@123
or Register a new User